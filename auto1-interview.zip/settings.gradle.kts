rootProject.name = "auto1-interview"

